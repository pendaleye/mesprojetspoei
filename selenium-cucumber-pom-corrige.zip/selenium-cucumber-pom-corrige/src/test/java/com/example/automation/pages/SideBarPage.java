package com.example.automation.pages;

import org.openqa.selenium.WebDriver;

public class SideBarPage extends BasePage {

    public SideBarPage(WebDriver driver) {
        super(driver);
    }

}
