package Miniprojet;

class Avion extends Vehicule{
    String moteur;
    int heuresVol;

    public Avion(String marque, int dateAchat, double prixAchat, String moteur, int heuresVol){
        super(marque,dateAchat,prixAchat);
        this.moteur=moteur;
        this.heuresVol=heuresVol;
    }
    @Override
    public void calculePrix(int anneeActuelle) {
        prixCourant = prixAchat;
        int temp=0;
        if (moteur.equalsIgnoreCase("HELICES")) {
             temp = heuresVol / 100;
            prixCourant -= prixAchat * 0.10 * temp;
        } else {
            int tranches = heuresVol / 1000;
            prixCourant -= prixAchat * 0.10 * temp;
        }

        if (prixCourant < 0) {
            prixCourant = 0;
        }
    }

    @Override
    public void affiche() {
        super.affiche();
        System.out.println("le moteur : " + moteur);
        System.out.println("heure de vol : " + heuresVol);
    }
}


